import numpy as np
import matplotlib.pyplot as plt
import os

def validate(signals, corridor_data, save_path="results/validation"):
    """Проверяет сигналы на соответствие коридорам"""
    os.makedirs(save_path, exist_ok=True)
    
    mean = corridor_data["mean"]
    std = corridor_data["std"]
    time_points = corridor_data["time"]

    one_sigma = (mean - std, mean + std)
    two_sigma = (mean - 2*std, mean + 2*std)
    three_sigma = (mean - 3*std, mean + 3*std)

    results = []
    
    for idx, signal in enumerate(signals):
        signal = np.array(signal)
        length = min(len(signal), len(mean))

        # Расчет попадания в коридоры для каждой точки
        in_1sigma = (signal > one_sigma[0][:length]) & (signal < one_sigma[1][:length])
        in_2sigma = (signal > two_sigma[0][:length]) & (signal < two_sigma[1][:length])
        in_3sigma = (signal > three_sigma[0][:length]) & (signal < three_sigma[1][:length])

        # Разбиваем сигнал на 10 сегментов для анализа
        segments = 10
        segment_len = length // segments
        segment_1sigma = []
        segment_2sigma = []
        segment_3sigma = []

        for i in range(segments):
            start = i * segment_len
            end = (i + 1) * segment_len if i < segments - 1 else length
            
            # Процент попадания в каждом сегменте
            seg_1sigma = np.mean(in_1sigma[start:end]) * 100
            seg_2sigma = np.mean(in_2sigma[start:end]) * 100
            seg_3sigma = np.mean(in_3sigma[start:end]) * 100
            
            segment_1sigma.append(seg_1sigma)
            segment_2sigma.append(seg_2sigma)
            segment_3sigma.append(seg_3sigma)

        # Сохраняем результаты для каждого сигнала
        results.append({
            'signal_num': idx + 1,
            'pathology_type': f'Патология_{idx}' if idx > 0 else 'Эталон',
            'мин_1σ': round(min(segment_1sigma), 2),
            'ср_1σ': round(np.mean(segment_1sigma), 2),
            'макс_1σ': round(max(segment_1sigma), 2),
            'мин_2σ': round(min(segment_2sigma), 2),
            'ср_2σ': round(np.mean(segment_2sigma), 2),
            'макс_2σ': round(max(segment_2sigma), 2),
            'мин_3σ': round(min(segment_3sigma), 2),
            'ср_3σ': round(np.mean(segment_3sigma), 2),
            'макс_3σ': round(max(segment_3sigma), 2)
        })

        # Построение графиков только для первых 5 сигналов
        if idx < 5:
            plt.figure(figsize=(10, 6))
            plt.plot(time_points[:length], signal, label='Сигнал')
            plt.plot(time_points[:length], mean[:length], '--', color='red', label='Среднее')
            plt.fill_between(time_points[:length], one_sigma[0][:length], one_sigma[1][:length],
                            color='green', alpha=0.2, label='1σ')
            plt.fill_between(time_points[:length], two_sigma[0][:length], two_sigma[1][:length],
                            color='orange', alpha=0.2, label='2σ')
            plt.fill_between(time_points[:length], three_sigma[0][:length], three_sigma[1][:length],
                            color='yellow', alpha=0.2, label='3σ')

            # Отображаем средние значения по всему сигналу
            text_str = (f"Вхождение в коридоры (среднее):\n"
                       f"1σ: {results[-1]['ср_1σ']:.1f}%\n"
                       f"2σ: {results[-1]['ср_2σ']:.1f}%\n"
                       f"3σ: {results[-1]['ср_3σ']:.1f}%")
            
            plt.text(0.02, 0.98, text_str, 
                    transform=plt.gca().transAxes,
                    verticalalignment='top',
                    bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))

            title = "Эталон" if idx == 0 else f"Патология {idx}"
            plt.title(f"Валидация: {title}")
            plt.xlabel("Время (с)")
            plt.ylabel("Отклик")
            plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.25), ncol=4)
            plt.grid(True)
            plt.tight_layout()
            
            plt.savefig(os.path.join(save_path, f"validation_{idx+1}.png"),
                       dpi=150,
                       metadata={'CreationDate': None})
            plt.close()

    return {
        'noise_level': 10,
        'results': results
    }