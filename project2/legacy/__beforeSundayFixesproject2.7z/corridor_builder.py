import numpy as np
import matplotlib.pyplot as plt
import os

def build_corridors(signals, save_path="results/corridors"):
    """Строит сигма-коридоры на основе сигналов"""
    os.makedirs(save_path, exist_ok=True)
    data_array = np.array(signals)
    
    mean_values = np.nanmean(data_array, axis=0)
    std_values = np.nanstd(data_array, axis=0)
    time_points = np.linspace(0, 10, len(mean_values))

    # Границы коридоров
    one_sigma = (mean_values - std_values, mean_values + std_values)
    two_sigma = (mean_values - 2*std_values, mean_values + 2*std_values)
    three_sigma = (mean_values - 3*std_values, mean_values + 3*std_values)

    # Визуализация
    plt.figure(figsize=(10, 6))
    plt.plot(time_points, mean_values, '--', color='red', label='Среднее')
    plt.fill_between(time_points, *one_sigma, color='green', alpha=0.2, label='1σ')
    plt.fill_between(time_points, *two_sigma, color='orange', alpha=0.2, label='2σ')
    plt.fill_between(time_points, *three_sigma, color='yellow', alpha=0.2, label='3σ')

    plt.title("Сигма-коридоры")
    plt.xlabel("Время (с)")
    plt.ylabel("Отклик")
    plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.15), ncol=4, fontsize=10)
    plt.grid(True)
    plt.tight_layout()
    
    # Сохраняем график с явным указанием кодировки в метаданных
    plt.savefig(os.path.join(save_path, "sigma_corridors.png"), 
               dpi=150, 
               metadata={'CreationDate': None, 'Software': None, 'Comment': 'UTF-8'})
    plt.close()

    return {
        "mean": mean_values,
        "std": std_values,
        "time": time_points,
        "noise_level": 10
    }