import numpy as np
import pandas as pd

def load_data():
    """Загружает данные из CSV файла"""
    data = pd.read_csv('data.csv', header=None)
    time_points = data.iloc[:, 0].values
    reference = data.iloc[:, 1].values
    pathologies = [data.iloc[:, i].values for i in range(2, data.shape[1])]
    return time_points, reference, pathologies

def generate_noisy_signals(reference, num_signals=50, noise_level=0.1):
    """Генерирует зашумленные версии эталонного сигнала"""
    signal_std = np.std(reference)
    noisy_signals = []
    
    for _ in range(num_signals):
        noise = np.random.normal(0, noise_level * signal_std, size=len(reference))
        noisy_signals.append(reference + noise)
    
    return noisy_signals