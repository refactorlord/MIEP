import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import lti, lsim

# Параметры времени
dt = 0.001                # шаг времени
duration = 10             # длительность моделирования
time_points = np.arange(0, duration, dt)

# === ВХОДНОЙ СИГНАЛ ===
def generate_pulse_signal(amplitude=10000, period=20, pulse_width=0.05, phase_delay=0.004):
    signal = np.zeros_like(time_points)
    for i, t in enumerate(time_points):
        if t >= phase_delay and (t % period) <= pulse_width * period:
            signal[i] = amplitude
    return signal

# === ПЕРЕДАТОЧНЫЕ ФУНКЦИИ ===
def simulate_transfer_function(signal, numerator, denominator, dt=0.001):
    num = np.array(numerator, dtype=float)
    den = np.array(denominator, dtype=float)

    output = np.zeros_like(signal)
    y_prev = 0.0

    for i in range(len(signal)):
        dy = (signal[i] - y_prev) * dt / den[1]
        y_prev += dy
        output[i] = y_prev

    return output

def apply_zero_pole(signal, time_points, zeros, poles, gain):
    sys = lti(zeros, poles, gain)
    _, y, _ = lsim(sys, signal, time_points)
    return y

def apply_transport_delay(signal, delay_time=0.01):
    delay_samples = int(delay_time / dt)
    delayed_signal = np.roll(signal, delay_samples)
    delayed_signal[:delay_samples] = 0
    return delayed_signal

def sum_signals(signals):
    return np.sum(signals, axis=0)

# === ПАРАМЕТРЫ БЛОКОВ ===
system_params = {
    'Fcn1': {'numerator': [1], 'denominator': [0.0051, 1]},
    'Fcn7': {'numerator': [1], 'denominator': [0.025, 1]},
    'Fcn9': {'numerator': [3.8], 'denominator': [0.45, 1]},
    'Fcn11': {'numerator': [1], 'denominator': [0.015, 1]},
    'Fcn14': {'numerator': [-2.6], 'denominator': [0.306, 1]},
    'Fcn17': {'numerator': [1], 'denominator': [0.027, 1]},
    'Zero-Pole2': {'zeros': [-0.6], 'poles': [-95, -95], 'gain': 13.5},
    'Zero-Pole5': {'zeros': [-0.9], 'poles': [-42, -42], 'gain': -1.6}
}

# === ГЕНЕРАЦИЯ СИГНАЛА ===
input_signal = generate_pulse_signal()

print("Входной сигнал:")
print(input_signal[:10])

# === ОСНОВНЫЕ ВЕТВИ ===
output_fcn1 = simulate_transfer_function(input_signal, system_params['Fcn1']['numerator'], system_params['Fcn1']['denominator'], dt=dt)

print("После Fcn1:", output_fcn1[:10])

# --- Параллельная группа 1: Fcn7 → Fcn9 ---
output_fcn7 = simulate_transfer_function(output_fcn1, system_params['Fcn7']['numerator'], system_params['Fcn7']['denominator'], dt=dt)
output_fcn9 = simulate_transfer_function(output_fcn7, system_params['Fcn9']['numerator'], system_params['Fcn9']['denominator'], dt=dt)

print("После Fcn9:", output_fcn9[:10])

# --- Параллельная группа 2: Fcn11 → Fcn14 ---
output_fcn11 = simulate_transfer_function(output_fcn1, system_params['Fcn11']['numerator'], system_params['Fcn11']['denominator'], dt=dt)
output_fcn14 = simulate_transfer_function(output_fcn11, system_params['Fcn14']['numerator'], system_params['Fcn14']['denominator'], dt=dt)

print("После Fcn14:", output_fcn14[:10])

# --- Дополнительные ветви: Fcn17 → Zero-Pole2 и Fcn17 → Zero-Pole5 ---
output_fcn17 = simulate_transfer_function(input_signal, system_params['Fcn17']['numerator'], system_params['Fcn17']['denominator'], dt=dt)

# Delay → Zero-Pole2
delayed_signal = apply_transport_delay(output_fcn17, delay_time=0.01)
zero_pole2_output = apply_zero_pole(delayed_signal, time_points,
                                    system_params['Zero-Pole2']['zeros'],
                                    system_params['Zero-Pole2']['poles'],
                                    system_params['Zero-Pole2']['gain'])

print("После Transport Delay:", delayed_signal[:10])
print("После Zero-Pole2:", zero_pole2_output[:10])

# Fcn17 → Zero-Pole5
zero_pole5_output = apply_zero_pole(output_fcn17, time_points,
                                   system_params['Zero-Pole5']['zeros'],
                                   system_params['Zero-Pole5']['poles'],
                                   system_params['Zero-Pole5']['gain'])

print("После Zero-Pole5:", zero_pole5_output[:10])

# === СУММИРОВАНИЕ ВСЕХ ВЕТЕВЕЙ ===
combined_signal = sum_signals([
    output_fcn9,
    output_fcn14,
    zero_pole2_output,
    zero_pole5_output
])

print("Объединённый сигнал:", combined_signal[:10])

# === ВИЗУАЛИЗАЦИЯ РЕЗУЛЬТАТА ===
plt.figure(figsize=(12, 6))
plt.plot(time_points, combined_signal, label='Финальный отклик')
plt.title('Выходной сигнал модели сетчатки глаза')
plt.xlabel('Время (с)')
plt.ylabel('Отклик')
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()