import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt

class KolosovSOlModel:
    def __init__(self):
        # Транспортная задержка
        self.transport_delay_time = 0.01
        self.buffer_size = 1024
        self.time_buffer = np.zeros(self.buffer_size)
        self.signal_buffer = np.zeros(self.buffer_size)
        self.head = 0
        self.tail = 0
        self.last_index = 0

        # Параметры блоков
        self.system_params = {
            'Fcn1': {'numerator': [1], 'denominator': [0.0051, 1]},
            'Fcn7': {'numerator': [1], 'denominator': [0.025, 1]},
            'Fcn9': {'numerator': [3.8], 'denominator': [0.45, 1]},
            'Fcn11': {'numerator': [1], 'denominator': [0.015, 1]},
            'Fcn14': {'numerator': [-2.6], 'denominator': [0.306, 1]},
            'Fcn17': {'numerator': [1], 'denominator': [0.027, 1]},
            'Zero-Pole2': {'zeros': [-0.6], 'poles': [-95, -95], 'gain': 13.5},
            'Zero-Pole5': {'zeros': [-0.9], 'poles': [-42, -42], 'gain': -1.6}
        }

        # Состояния модели (11 состояний)
        self.states = np.zeros(11)  # Начальные условия

        # Пульсогенератор
        self.pulse_width = 5
        self.pulse_period = 10000
        self.pulse_counter = -2  # Теперь правильно инициализирован

    def pulse_generator(self, t):
        counter = self.pulse_counter + 1
        if counter >= self.pulse_period:
            counter = 0
        self.pulse_counter = counter
        return 10000.0 if 0 <= counter < self.pulse_width else 0.0

    def transport_delay_output(self, t_minus_delay):
        if t_minus_delay <= 0:
            return 0.0

        head = self.head
        tail = self.tail
        last_index = self.last_index

        if head == 0 and tail == 0:
            return 0.0

        i = last_index
        while self.time_buffer[i] < t_minus_delay:
            if i == head:
                break
            i = (i + 1) % self.buffer_size

        while self.time_buffer[i] >= t_minus_delay:
            i = (i - 1) % self.buffer_size

        i = (i + 1) % self.buffer_size
        self.last_index = i

        t1 = self.time_buffer[i - 1] if i > 0 else self.time_buffer[-1]
        t2 = self.time_buffer[i]
        y1 = self.signal_buffer[i - 1] if i > 0 else self.signal_buffer[-1]
        y2 = self.signal_buffer[i]

        if t2 == t1:
            return y2 if t_minus_delay >= t2 else y1

        f1 = (t2 - t_minus_delay) / (t2 - t1)
        f2 = 1.0 - f1
        return f1 * y1 + f2 * y2

    def update_transport_delay(self, t, u):
        self.head = (self.head + 1) % self.buffer_size
        if self.head == self.tail:
            self.tail = (self.tail + 1) % self.buffer_size
        self.signal_buffer[self.head] = u
        self.time_buffer[self.head] = t

    def system_dynamics(self, t, x):
        """
        Вычисляет производные для всех 11 состояний модели.
        """
        tf9_out = x[0]
        tf14_out = x[1]
        zp2_state = x[2:4]
        zp5_state = x[4:6]
        integrator_state = x[6]
        tf1_out = x[7]
        tf11_out = x[8]
        tf17_out = x[9]
        tf7_out = x[10]

        # Выходы Zero-Pole блоков
        zp2_out = (
            13.5 * zp2_state[1]  # gain * state[1]
        )
        zp5_out = (
            -1.6 * zp5_state[1]  # gain * state[1]
        )

        sum2 = (
            (3.8 / 0.45 * tf9_out - (-2.6 / 0.306) * tf14_out) * 0.5 +
            13.5 * zp2_state[0] + 0.085263157894736846 * zp2_state[1] +
            (-1.6 * zp5_state[0] - 0.034285714285714287 * zp5_state[1])
        )
        product = sum2 * sum2

        dxdt = np.zeros_like(x)

        # Производные TransferFcn
        dxdt[0] = -1 / 0.45 * tf9_out + tf7_out
        dxdt[1] = -1 / 0.306 * tf14_out + tf11_out
        dxdt[7] = -1 / 0.0051 * tf1_out + self.pulse_generator(t)
        dxdt[8] = -1 / 0.015 * tf11_out + tf1_out
        dxdt[9] = -1 / 0.027 * tf17_out + tf1_out
        dxdt[10] = -1 / 0.025 * tf7_out + tf1_out

        # Производные ZeroPole2
        dxdt[2] = -95.0 * zp2_state[0] - 95.0 * zp2_state[1] + self.transport_delay_output(t - self.transport_delay_time)
        dxdt[3] = 95.0 * zp2_state[0]

        # Производные ZeroPole5
        dxdt[4] = -42.0 * zp5_state[0] - 42.0 * zp5_state[1] + tf1_out
        dxdt[5] = 42.0 * zp5_state[0]

        # Интегратор
        dxdt[6] = product

        return dxdt

    def simulate(self, t_span, dt):
        t_eval = np.arange(t_span[0], t_span[1], dt)
        sol = solve_ivp(
            fun=self.system_dynamics,
            t_span=t_span,
            y0=self.states,
            t_eval=t_eval,
            method='RK45',
            rtol=1e-6,
            atol=1e-8
        )

        output = []
        for i in range(len(sol.t)):
            t_i = sol.t[i]
            y_i = sol.y[:, i]

            self.states = y_i.copy()

            self.update_transport_delay(t_i, y_i[9])  # tf17_out

            tf9_out = y_i[0]
            tf14_out = y_i[1]
            zp2_state = y_i[2:4]
            zp5_state = y_i[4:6]

            sum2 = (
                (3.8 / 0.45 * tf9_out - (-2.6 / 0.306) * tf14_out) * 0.5 +
                13.5 * zp2_state[0] + 0.085263157894736846 * zp2_state[1] +
                (-1.6 * zp5_state[0] - 0.034285714285714287 * zp5_state[1])
            )
            output.append(sum2)

        return sol.t, np.array(output)


def plot_response(t, y, filename="graph.png"):
    plt.figure(figsize=(12, 6))
    plt.plot(t, y)
    plt.title('Отклик системы')
    plt.xlabel('Время (с)')
    plt.ylabel('Выходной сигнал')
    plt.grid(True)
    #plt.savefig(filename)
    plt.show()


model = KolosovSOlModel()
t_start = -5.5
t_end = 2.5
dt = 0.02
t_span = [t_start, t_end]
time, response = model.simulate(t_span, dt)
plot_response(time, response)