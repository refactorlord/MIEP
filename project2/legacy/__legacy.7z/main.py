import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import lti, lsim
import os

# === ПАРАМЕТРЫ МОДЕЛИ ГЛАЗА ===
system_params = {
    'Fcn1': {'numerator': [1], 'denominator': [0.0051, 1]},
    'Fcn7': {'numerator': [1], 'denominator': [0.025, 1]},
    'Fcn9': {'numerator': [3.8], 'denominator': [0.45, 1]},
    'Fcn11': {'numerator': [1], 'denominator': [0.015, 1]},
    'Fcn14': {'numerator': [-2.6], 'denominator': [0.306, 1]},
    'Fcn17': {'numerator': [1], 'denominator': [0.027, 1]},
    'Zero-Pole2': {'zeros': [-0.6], 'poles': [-95, -95], 'gain': 13.5},
    'Zero-Pole5': {'zeros': [-0.9], 'poles': [-42, -42], 'gain': -1.6}
}

# === ПАРАМЕТРЫ СИМУЛЯЦИЙ ===
dt = 0.001                # шаг времени
duration = 10             # длительность моделирования
time_points = np.arange(0, duration, dt)

# === ВХОДНОЙ СИГНАЛ (ступенчатое воздействие) ===
def generate_step_signal(amplitude=10000):
    signal = np.ones_like(time_points) * amplitude
    return signal

# === ПЕРЕДАТОЧНЫЕ ФУНКЦИИ ===
def simulate_transfer_function(signal, numerator, denominator, dt=0.001):
    output = np.zeros_like(signal)
    y_prev = 0.0

    for i in range(len(signal)):
        dy = (signal[i] - y_prev) * dt / denominator[1]
        y_prev += dy
        output[i] = y_prev

    return output

def apply_zero_pole(signal, time_points, zeros, poles, gain):
    sys = lti(zeros, poles, gain)
    _, y, _ = lsim(sys, signal, time_points)
    return y

def sum_signals(signals):
    return np.sum(signals, axis=0)

# === ОСНОВНОЙ ЦИКЛ ===
if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)

    input_signal = generate_step_signal(amplitude=10000)
    print("Входной сигнал:", input_signal[:10])

    # === ОСНОВНЫЕ ВЕТВИ ===
    output_fcn1 = simulate_transfer_function(input_signal, system_params['Fcn1']['numerator'], system_params['Fcn1']['denominator'], dt=dt)
    print("После Fcn1:", output_fcn1[:10])

    output_fcn7 = simulate_transfer_function(output_fcn1, system_params['Fcn7']['numerator'], system_params['Fcn7']['denominator'], dt=dt)
    output_fcn9 = simulate_transfer_function(output_fcn7, system_params['Fcn9']['numerator'], system_params['Fcn9']['denominator'], dt=dt)
    print("После Fcn9:", output_fcn9[:10])

    output_fcn11 = simulate_transfer_function(output_fcn1, system_params['Fcn11']['numerator'], system_params['Fcn11']['denominator'], dt=dt)
    output_fcn14 = simulate_transfer_function(output_fcn11, system_params['Fcn14']['numerator'], system_params['Fcn14']['denominator'], dt=dt)
    print("После Fcn14:", output_fcn14[:10])

    # --- Дополнительные ветви: Fcn17 → Zero-Pole2 и Fcn17 → Zero-Pole5 ---
    output_fcn17 = simulate_transfer_function(input_signal, system_params['Fcn17']['numerator'], system_params['Fcn17']['denominator'], dt=dt)
    print("После Fcn17:", output_fcn17[:10])

    zero_pole2_output = apply_zero_pole(output_fcn17, time_points,
                                        system_params['Zero-Pole2']['zeros'],
                                        system_params['Zero-Pole2']['poles'],
                                        system_params['Zero-Pole2']['gain'])

    print("После Zero-Pole2:", zero_pole2_output[:10])

    zero_pole5_output = apply_zero_pole(output_fcn17, time_points,
                                       system_params['Zero-Pole5']['zeros'],
                                       system_params['Zero-Pole5']['poles'],
                                       system_params['Zero-Pole5']['gain'])

    print("После Zero-Pole5:", zero_pole5_output[:10])

    # === СУММИРОВАНИЕ ВСЕХ ВЕТЕВЕЙ ===
    combined_signal = sum_signals([
        output_fcn9,
        output_fcn14,
        zero_pole2_output,
        zero_pole5_output
    ])

    print("Объединённый сигнал:", combined_signal[:10])

    # === ИНТЕГРИРОВАНИЕ ===
    def integrate_signal(signal, dt=0.001):
        return np.cumsum(signal) * dt

    integrated_signal = integrate_signal(combined_signal, dt=dt)
    print("Проинтегрированный сигнал:", integrated_signal[:10])

    # === ВИЗУАЛИЗАЦИЯ РЕЗУЛЬТАТА ===
    plt.figure(figsize=(12, 6))
    plt.plot(time_points, integrated_signal, label='Финальный отклик')
    plt.title('Выходной сигнал модели сетчатки глаза')
    plt.xlabel('Время (с)')
    plt.ylabel('Отклик')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig("results/retina_response.png")
    plt.show()

    print("✅ Отклик системы сохранён в файл results/retina_response.png")