import numpy as np
import pandas as pd
from scipy import interpolate
import os

def load_data(filename='data.csv'):
    """Загружает данные и проводит ресемплинг всех сигналов к единой временной сетке"""
    # Чтение данных с учетом заголовков
    data = pd.read_csv(filename, header=0)
    time_col = data.columns[0]
    
    # Определяем общую временную ось (берем все уникальные временные точки)
    all_time_points = np.unique(data[time_col].dropna().values)
    full_time = np.linspace(all_time_points.min(), all_time_points.max(), len(all_time_points))
    
    # Создаем DataFrame для интерполированных данных
    processed_data = pd.DataFrame({time_col: full_time})
    
    for col in data.columns[1:]:
        # Извлекаем данные для текущего сигнала (игнорируем строки с NaN)
        valid_data = data[[time_col, col]].dropna()
        time_valid = valid_data[time_col].values
        signal_valid = valid_data[col].values
        
        # Если данных недостаточно для интерполяции, используем нули
        if len(time_valid) < 2:
            print(f"Предупреждение: недостаточно данных для интерполяции {col}")
            processed_data[col] = np.zeros_like(full_time)
            continue
            
        # Создаем интерполяционную функцию (кусочно-линейная интерполяция)
        interp_func = interpolate.interp1d(
            time_valid,
            signal_valid,
            kind='linear',
            fill_value="extrapolate"
        )
        
        # Применяем интерполяцию
        try:
            processed_data[col] = interp_func(full_time)
        except Exception as e:
            print(f"Ошибка интерполяции для {col}: {str(e)}")
            processed_data[col] = np.zeros_like(full_time)
    
    # Сохраняем интерполированные данные
    os.makedirs('results', exist_ok=True)
    processed_data.to_csv('results/data_interp.csv', index=False, encoding='utf-8-sig')
    
    # Разделение на эталон и патологии
    reference = processed_data.iloc[:, 1].values
    pathologies = [processed_data.iloc[:, i].values for i in range(2, processed_data.shape[1])]
    pathology_names = data.columns[2:].tolist()
    
    return full_time, reference, pathologies, pathology_names

def generate_noisy_signals(reference, num_signals=50, noise_level=0.1):
    """Генерирует зашумленные версии эталонного сигнала"""
    valid_values = reference[~np.isnan(reference)]
    if len(valid_values) == 0:
        return [np.zeros_like(reference) for _ in range(num_signals)]
    
    signal_std = np.std(valid_values)
    noisy_signals = []
    
    for _ in range(num_signals):
        noise = np.random.normal(0, noise_level * signal_std, size=len(reference))
        noisy_signal = reference + noise
        noisy_signals.append(noisy_signal)
    
    return noisy_signals