import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

def generate_summary_table(results_data, filename="results/analysis_summary.csv"):
    df = pd.DataFrame(results_data)
    df.to_csv(filename, index=False, encoding='utf-8-sig')
    print(f"Сводная таблица сохранена: {filename}")


def plot_distinguishability_matrix(matrix, x_labels, y_labels, matrix_type, noise_level, filename="results/matrix.png"):
    plt.figure(figsize=(10, 6))
    sns.heatmap(matrix, annot=True, fmt=".2f", xticklabels=x_labels, yticklabels=y_labels, cmap="YlGnBu", linewidths=.5)
    plt.title(f"Матрица отличимости ({matrix_type}, уровень шума {noise_level}%")
    plt.xlabel("Тестовые значения T")
    plt.ylabel("Тип звена")
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()
    print(f"Матрица {matrix_type} сохранена: {filename}")