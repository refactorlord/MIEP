import numpy as np
import matplotlib.pyplot as plt
import os

def cross_validate(data, corridor_data, save_path="results/cross_validation"):
    os.makedirs(save_path, exist_ok=True)

    mean_values = corridor_data['mean']
    std_values = corridor_data['std']
    time_points = corridor_data['time']

    one_sigma_upper = mean_values + std_values
    two_sigma_upper = mean_values + 2 * std_values
    three_sigma_upper = mean_values + 3 * std_values
    one_sigma_lower = mean_values - std_values
    two_sigma_lower = mean_values - 2 * std_values
    three_sigma_lower = mean_values - 3 * std_values

    percent_in_1sigma_all = []
    percent_in_2sigma_all = []
    percent_in_3sigma_all = []

    for idx, series in enumerate(data):
        if idx >= 5:
            break
        series = np.array(series)
        length = min(len(series), len(mean_values))

        in_1sigma = ((series >= one_sigma_lower[:length]) & (series <= one_sigma_upper[:length])).sum() / length * 100
        in_2sigma = ((series >= two_sigma_lower[:length]) & (series <= two_sigma_upper[:length])).sum() / length * 100
        in_3sigma = ((series >= three_sigma_lower[:length]) & (series <= three_sigma_upper[:length])).sum() / length * 100

        percent_in_1sigma_all.append(in_1sigma)
        percent_in_2sigma_all.append(in_2sigma)
        percent_in_3sigma_all.append(in_3sigma)

        plt.figure(figsize=(10, 6))
        plt.plot(time_points[:length], series, label='Сигнал')
        plt.plot(time_points[:length], mean_values[:length], '--', color='red', label='Среднее')
        plt.fill_between(time_points[:length], one_sigma_lower[:length], one_sigma_upper[:length],
                         color='green', alpha=0.2, label='1σ')
        plt.fill_between(time_points[:length], two_sigma_lower[:length], two_sigma_upper[:length],
                         color='orange', alpha=0.2, label='2σ')
        plt.fill_between(time_points[:length], three_sigma_lower[:length], three_sigma_upper[:length],
                         color='yellow', alpha=0.2, label='3σ')
        plt.text(0.5, 0.95, 
                 f"В 1σ: {in_1sigma:.1f}%\n"
                 f"В 2σ: {in_2sigma:.1f}%\n"
                 f"В 3σ: {in_3sigma:.1f}%",
                 transform=plt.gca().transAxes, ha='center', va='top', fontsize=10)
        plt.title(f"Кросс-валидация №{idx+1}")
        plt.xlabel("Время (с)")
        plt.ylabel("Отклик")
        plt.legend()
        plt.grid(True)
        plt.savefig(os.path.join(save_path, f"cross_validation_{idx+1}.png"))
        plt.close()

    return {
        'avg_1sigma': np.mean(percent_in_1sigma_all),
        'avg_2sigma': np.mean(percent_in_2sigma_all),
        'avg_3sigma': np.mean(percent_in_3sigma_all)
    }