import numpy as np
import matplotlib.pyplot as plt
import os

def build_corridors(data, save_path="results/corridors"):
    os.makedirs(save_path, exist_ok=True)

    data_array = np.array(data)
    mean_values = np.nanmean(data_array, axis=0)
    std_values = np.nanstd(data_array, axis=0)

    time_points = np.linspace(0, 10, len(mean_values))

    one_sigma_upper = mean_values + std_values
    two_sigma_upper = mean_values + 2 * std_values
    three_sigma_upper = mean_values + 3 * std_values
    one_sigma_lower = mean_values - std_values
    two_sigma_lower = mean_values - 2 * std_values
    three_sigma_lower = mean_values - 3 * std_values

    corridor_data = {
        "mean": mean_values,
        "std": std_values,
        "time": time_points
    }
    np.save(os.path.join(save_path, "corridor_stats.npy"), corridor_data)

    plt.figure(figsize=(12, 6))
    for row in data_array[:5]:  # только первые 5 для наглядности
        plt.plot(time_points, row, color='blue', alpha=0.2)

    plt.plot(time_points, mean_values, '--', label='Среднее значение', color='red')
    plt.fill_between(time_points, one_sigma_lower, one_sigma_upper, color='green', alpha=0.2, label='1σ коридор')
    plt.fill_between(time_points, two_sigma_lower, two_sigma_upper, color='orange', alpha=0.2, label='2σ коридор')
    plt.fill_between(time_points, three_sigma_lower, three_sigma_upper, color='yellow', alpha=0.2, label='3σ коридор')

    plt.title("Сигма-коридоры")
    plt.xlabel("Время (с)")
    plt.ylabel("Отклик")
    plt.legend()
    plt.grid(True)
    plt.savefig(os.path.join(save_path, "sigma_corridors.png"))
    plt.close()

    print("Sigma-коридоры построены и сохранены.")
    return corridor_data