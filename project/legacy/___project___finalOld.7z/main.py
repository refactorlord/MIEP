from simulation import simulate_system, save_to_file
from build_corridors import build_corridors
from validate_in_corridors import validate
from cross_validate import cross_validate
from visualize_results import generate_summary_table, plot_distinguishability_matrix
import os
import numpy as np

# Запрос данных у пользователя
base_T = float(input("Введите базовое значение T: "))
start_T = float(input("Начальное значение T: "))
end_T = float(input("Конечное значение T: "))
step_T = float(input("Шаг изменения T: "))

noise_levels_input = input("Уровни шума через пробел (например, 10 20 30): ")
NOISE_LEVELS = list(map(int, noise_levels_input.split()))

# Диапазон тестовых значений T
T_VALUES = np.arange(start_T, end_T + step_T / 10, step_T).round(2).tolist()

# Поддерживаемые типы звеньев
SYSTEM_PAIRS = [
    {
        'type': 'aperiodic',
        'name': 'Апериодическое',
        'norm_params': {'T': base_T},
        'test_params_list': [{'T': t} for t in T_VALUES]
    },
    {
        'type': 'oscillatory',
        'name': 'Колебательное',
        'norm_params': {'T': base_T, 'xi': 0.5},
        'test_params_list': [{'T': t, 'xi': 0.5} for t in T_VALUES]
    },
    {
        'type': 'integrating',
        'name': 'Интегрирующее',
        'norm_params': {'k': 1},
        'test_params_list': [{'k': round(k, 2)} for k in np.arange(start_T, end_T + step_T, step_T).tolist()]
    },
    {
        'type': 'inertial2',
        'name': 'Инерционное II',
        'norm_params': {'T1': base_T, 'T2': base_T},
        'test_params_list': [{'T1': t, 'T2': base_T} for t in T_VALUES]
    }
]

TYPES = [s['type'] for s in SYSTEM_PAIRS]
LABELS = ['База'] + [f"T={t}" for t in T_VALUES]

all_results = []

for noise_level in NOISE_LEVELS:
    print(f"\n{'=' * 60}\nОбработка уровня шума: {noise_level}%\n{'=' * 60}")

    base_dir = f"results/noise_{noise_level}"
    data_dir = os.path.join(base_dir, "data")
    corridor_dir = os.path.join(base_dir, "corridors")
    validation_dir = os.path.join(base_dir, "validation")
    cross_validation_dir = os.path.join(base_dir, "cross_validation")

    os.makedirs(data_dir, exist_ok=True)

    distinguishability_data_1sigma = []
    distinguishability_data_2sigma = []
    distinguishability_data_3sigma = []

    for system_info in SYSTEM_PAIRS:
        system_type = system_info['type']
        system_name = system_info['name']
        base_params = system_info['norm_params']
        test_params_list = system_info['test_params_list']

        print(f"\nТип звена: {system_name}")

        simulations_norm = simulate_system(
            num_simulations=100,
            num_points=500,
            noise_level=noise_level / 100,
            system_type=system_type,
            params=base_params
        )
        save_to_file(simulations_norm, os.path.join(data_dir, f"{system_type}_base.csv"))

        training_data = simulations_norm[:50]
        corridor_data = build_corridors(training_data, save_path=os.path.join(corridor_dir, system_type))

        percent_1sigma_list = []
        percent_2sigma_list = []
        percent_3sigma_list = []

        for test_idx, test_params in enumerate(test_params_list):
            test_value = test_params.get('T', test_params.get('k', test_params.get('T1')))
            print(f"→ Тестирование с T={test_value}")

            simulations_other = simulate_system(
                num_simulations=100,
                num_points=500,
                noise_level=noise_level / 100,
                system_type=system_type,
                params=test_params
            )

            result = cross_validate(simulations_other, corridor_data, save_path=cross_validation_dir)

            percent_1sigma_list.append(result['avg_1sigma'])
            percent_2sigma_list.append(result['avg_2sigma'])
            percent_3sigma_list.append(result['avg_3sigma'])

        all_results.extend([
            {
                'тип_звена': system_name,
                'параметр': T_VALUES[i] if i < len(T_VALUES) else 0,
                'уровень_шума': noise_level,
                '1σ': percent_1sigma_list[i] if i < len(percent_1sigma_list) else 0,
                '2σ': percent_2sigma_list[i] if i < len(percent_2sigma_list) else 0,
                '3σ': percent_3sigma_list[i] if i < len(percent_3sigma_list) else 0
            } for i in range(len(test_params_list))  # ← Важная правка
        ])

        distinguishability_data_1sigma.append(percent_1sigma_list)
        distinguishability_data_2sigma.append(percent_2sigma_list)
        distinguishability_data_3sigma.append(percent_3sigma_list)

    # Сохраняем тепловые карты по всем уровням сигмы
    plot_distinguishability_matrix(
        np.array(distinguishability_data_1sigma),
        x_labels=[f"T={t}" for t in T_VALUES],
        y_labels=[s['name'] for s in SYSTEM_PAIRS],
        matrix_type="Выход за 1σ",
        noise_level=noise_level,
        filename=os.path.join(base_dir, "distinguishability_1sigma.png")
    )

    plot_distinguishability_matrix(
        np.array(distinguishability_data_2sigma),
        x_labels=[f"T={t}" for t in T_VALUES],
        y_labels=[s['name'] for s in SYSTEM_PAIRS],
        matrix_type="Выход за 2σ",
        noise_level=noise_level,
        filename=os.path.join(base_dir, "distinguishability_2sigma.png")
    )

    plot_distinguishability_matrix(
        np.array(distinguishability_data_3sigma),
        x_labels=[f"T={t}" for t in T_VALUES],
        y_labels=[s['name'] for s in SYSTEM_PAIRS],
        matrix_type="Выход за 3σ",
        noise_level=noise_level,
        filename=os.path.join(base_dir, "distinguishability_3sigma.png")
    )

generate_summary_table(all_results, filename="results/analysis_summary.csv")
print("\n✅ Все тепловые карты построены для каждого уровня шума")
print("Графики: distinguishability_1sigma.png, 2σ, 3σ")