from simulation import simulate_system
from build_corridors import build_corridors
from validate_in_corridors import validate
from cross_validate import cross_validate
import os
import pandas as pd
import numpy as np

# Поддерживаемые типы звеньев
SYSTEM_PAIRS = [
    {
        'type': 'aperiodic',
        'name': 'Апериодическое',
        'norm_params': {'T': 1},
    },
    {
        'type': 'oscillatory',
        'name': 'Колебательное',
        'norm_params': {'T': 1, 'xi': 0.5},
    },
    {
        'type': 'integrating',
        'name': 'Интегрирующее',
        'norm_params': {'k': 1},
    }
]

# Пользовательский ввод
base_T = float(input("Введите базовое значение T: "))
start_T = float(input("Начальное значение T: "))
end_T = float(input("Конечное значение T: "))
step_T = float(input("Шаг изменения T: "))
noise_levels_input = input("Уровни шума через пробел (например, 10 20 30): ")
NOISE_LEVELS = list(map(int, noise_levels_input.split()))

# Диапазон тестовых T
T_VALUES = []
t = start_T
while t <= end_T + 1e-6:
    T_VALUES.append(round(t, 2))
    t += step_T

all_results = []

for system_info in SYSTEM_PAIRS:
    system_type = system_info['type']
    system_name = system_info['name']

    for noise_level in NOISE_LEVELS:
        print(f"\n{'='*60}\nОбработка: {system_name}, уровень шума={noise_level}%\n{'='*60}")

        # 1. Моделирование базового сигнала
        simulations = simulate_system(
            num_simulations=100,
            system_type=system_type,
            params=system_info['norm_params'],
            noise_level=noise_level / 100
        )

        # 2. Построение сигма-коридоров
        corridor_path = os.path.join("results", system_type, f"noise_{noise_level}")
        corridor_data = build_corridors(simulations[:50], save_path=corridor_path, system_info=system_info)

        # 3. Валидация
        val_result = validate(simulations[50:], corridor_data, save_path=os.path.join(corridor_path, "validation"))

        # 4. Кросс-валидация
        cv_results = cross_validate(simulations[50:], corridor_data, T_VALUES, save_path=os.path.join(corridor_path, "cross_validation"))

        all_results.extend(cv_results)

# Сохраняем сводную таблицу
df = pd.DataFrame(all_results)
df.to_csv("results/analysis_summary.csv", index=False, encoding="utf-8-sig")
print("\n✅ Все этапы завершены. Результаты сохранены в analysis_summary.csv")

# Тепловые карты
from visualize_results import plot_distinguishability_matrix

systems = df['тип_звена'].unique()
Ts = sorted(df['параметр'].unique())
noises = sorted(df['уровень_шума'].unique())

os.makedirs("results/heatmaps", exist_ok=True)

for system in systems:
    df_sys = df[df['тип_звена'] == system]
    matrix_3sigma = np.zeros((len(noises), len(Ts)))

    for i, noise in enumerate(noises):
        for j, T in enumerate(Ts):
            row = df_sys[(df_sys['уровень_шума'] == noise) & (df_sys['параметр'] == T)]
            if not row.empty:
                matrix_3sigma[i][j] = row.iloc[0]['3σ']

    plot_distinguishability_matrix(
        matrix_3sigma,
        Ts,
        noises,
        title=f"Процент точек внутри 3σ ({system})",
        filename=os.path.join("results", "heatmaps", f"{system}_3sigma_avg.png")
    )