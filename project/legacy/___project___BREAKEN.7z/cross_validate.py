import numpy as np
import matplotlib.pyplot as plt
import os

def cross_validate(data, corridor_data, test_T_values, save_path="results/cross_validation"):
    os.makedirs(save_path, exist_ok=True)

    mean_values = corridor_data["mean"]
    std_values = corridor_data["std"]
    time_points = corridor_data["time"]

    one_sigma_upper = mean_values + std_values
    one_sigma_lower = mean_values - std_values
    two_sigma_upper = mean_values + 2 * std_values
    two_sigma_lower = mean_values - 2 * std_values
    three_sigma_upper = mean_values + 3 * std_values
    three_sigma_lower = mean_values - 3 * std_values

    results = []

    for idx, T in enumerate(test_T_values):
        print(f"→ Тестирование с T={T}")

        if corridor_data['system_type'] == 'aperiodic':
            test_params = {'T': T}
        elif corridor_data['system_type'] == 'oscillatory':
            test_params = {'T': T, 'xi': 0.5}
        elif corridor_data['system_type'] == 'integrating':
            test_params = {'k': round(T, 2)}
        else:
            raise ValueError("Неизвестный тип звена")

        test_simulations = [data[idx % len(data)]]

        for series in test_simulations:
            series = np.array(series)
            length = min(len(series), len(mean_values))

            in_1sigma = ((series > one_sigma_lower[:length]) & (series < one_sigma_upper[:length])).sum() / length * 100
            in_2sigma = ((series > two_sigma_lower[:length]) & (series < two_sigma_upper[:length])).sum() / length * 100
            in_3sigma = ((series > three_sigma_lower[:length]) & (series < three_sigma_upper[:length])).sum() / length * 100

            plt.figure(figsize=(10, 6))
            plt.plot(time_points[:length], series, label='Сигнал')
            plt.plot(time_points[:length], mean_values[:length], '--', color='red', label='Среднее')
            plt.fill_between(time_points[:length], one_sigma_lower[:length], one_sigma_upper[:length],
                             color='green', alpha=0.2, label='1σ')
            plt.fill_between(time_points[:length], two_sigma_lower[:length], two_sigma_upper[:length],
                             color='orange', alpha=0.2, label='2σ')
            plt.fill_between(time_points[:length], three_sigma_lower[:length], three_sigma_upper[:length],
                             color='yellow', alpha=0.2, label='3σ')

            plt.text(0.5, 0.5,
                     f"В 1σ: {in_1sigma:.1f}%\n"
                     f"В 2σ: {in_2sigma:.1f}%\n"
                     f"В 3σ: {in_3sigma:.1f}%",
                     ha='center', va='center', transform=plt.gca().transAxes, fontsize=10)

            plt.title(f"Кросс-валидация: T={T}")
            plt.xlabel("Время (с)")
            plt.ylabel("Отклик")
            plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.15), ncol=5)
            plt.grid(True)
            plt.tight_layout()
            plt.savefig(os.path.join(save_path, f"T_{T}_{idx+1}.png"))
            plt.close()

            results.append({
                'тип_звена': corridor_data['system_name'],
                'параметр': T,
                'уровень_шума': corridor_data['noise_level'],
                '1σ': in_1sigma,
                '2σ': in_2sigma,
                '3σ': in_3sigma
            })

    return results