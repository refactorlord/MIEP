import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import os

def plot_distinguishability_matrix(matrix, x_labels, y_labels, title, filename):
    plt.figure(figsize=(10, 6))
    sns.heatmap(matrix, annot=True, fmt=".1f", cmap="YlGnBu", xticklabels=x_labels, yticklabels=y_labels)
    plt.title(title)
    plt.xlabel("Параметр T")
    plt.ylabel("Уровень шума (%)")
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()
    print(f"Матрица отличимости сохранена: {filename}")