import pandas as pd
import os

def generate_summary_table(results, filename="results/cross_validation_summary.csv"):
    os.makedirs(os.path.dirname(filename), exist_ok=True)

    # Создаём словарь для хранения данных по звену + T + шуму
    grouped = {}

    for result in results:
        key = (result['тип_звена'], result['параметр'], result['уровень_шума'])

        if key not in grouped:
            grouped[key] = {
                'min_1sigma': [],
                'avg_1sigma_list': [],
                'max_1sigma': [],
                'min_2sigma': [],
                'avg_2sigma_list': [],
                'max_2sigma': [],
                'min_3sigma': [],
                'avg_3sigma_list': [],
                'max_3sigma': []
            }

        # Собираем все значения для последующего анализа
        grouped[key]['avg_1sigma_list'].append(result['ср_1σ'])
        grouped[key]['avg_2sigma_list'].append(result['ср_2σ'])
        grouped[key]['avg_3sigma_list'].append(result['ср_3σ'])

    # Теперь формируем финальные данные
    summary_data = []

    for key, values in grouped.items():
        system_type, T, noise_level = key

        min_1sigma = min(values['avg_1sigma_list'])
        avg_1sigma = sum(values['avg_1sigma_list']) / len(values['avg_1sigma_list'])
        max_1sigma = max(values['avg_1sigma_list'])

        min_2sigma = min(values['avg_2sigma_list'])
        avg_2sigma = sum(values['avg_2sigma_list']) / len(values['avg_2sigma_list'])
        max_2sigma = max(values['avg_2sigma_list'])

        min_3sigma = min(values['avg_3sigma_list'])
        avg_3sigma = sum(values['avg_3sigma_list']) / len(values['avg_3sigma_list'])
        max_3sigma = max(values['avg_3sigma_list'])

        summary_data.append({
            'тип_звена': system_type,
            'параметр': T,
            'уровень_шума': noise_level,
            'мин_1σ': round(min_1sigma, 2),
            'ср_1σ': round(avg_1sigma, 2),
            'макс_1σ': round(max_1sigma, 2),
            'мин_2σ': round(min_2sigma, 2),
            'ср_2σ': round(avg_2sigma, 2),
            'макс_2σ': round(max_2sigma, 2),
            'мин_3σ': round(min_3sigma, 2),
            'ср_3σ': round(avg_3sigma, 2),
            'макс_3σ': round(max_3sigma, 2)
        })

    # Сохраняем в CSV
    df_summary = pd.DataFrame(summary_data)
    df_summary.to_csv(filename, index=False, encoding="utf-8-sig", float_format="%.2f")
    print(f"✅ Сводная таблица обновлена с реальными мин./ср./макс.: {filename}")