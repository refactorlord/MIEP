import pandas as pd
import os

def generate_summary_table(results, filename="results/summary_table.csv"):
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    
    systems = ['Апериодическое', 'Колебательное', 'Интегрирующее']
    summary_data = []

    for system in systems:
        for noise_level in sorted(set(r['уровень_шума'] for r in results if r['тип_звена'] == system)):
            filtered = [r for r in results if r['тип_звена'] == system and r['уровень_шума'] == noise_level]
            avg_1sigma = sum(r['avg_1sigma'] for r in filtered) / len(filtered)
            avg_2sigma = sum(r['avg_2sigma'] for r in filtered) / len(filtered)
            avg_3sigma = sum(r['avg_3sigma'] for r in filtered) / len(filtered)

            summary_data.append({
                'система': system,
                'шум': noise_level,
                '1σ': avg_1sigma,
                '2σ': avg_2sigma,
                '3σ': avg_3sigma
            })

    df = pd.DataFrame(summary_data)
    df_pivot = df.pivot(index='шум', columns='система', values=['1σ', '2σ', '3σ'])
    df_pivot.columns = [f"{col}_{typ}" for typ, col in df_pivot.columns]
    df_pivot.reset_index(inplace=True)
    df_pivot.to_csv(filename, index=False, encoding="utf-8-sig")
    print(f"Сводная таблица обновлена: {filename}")