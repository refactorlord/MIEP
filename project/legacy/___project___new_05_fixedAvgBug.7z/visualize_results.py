import seaborn as sns
import matplotlib.pyplot as plt
import os
import numpy as np

def generate_cross_validation_heatmaps(df, save_dir="results/heatmaps"):
    """
    Строит тепловые карты для каждого типа звена,
    где по оси X — значения T, по оси Y — уровень шума (%),
    цвет ячейки — среднее значение внутри 1σ, 2σ или 3σ.
    """

    os.makedirs(save_dir, exist_ok=True)

    # Уникальные типы звеньев
    types = df['тип_звена'].unique()
    Ts = sorted(df['параметр'].unique())
    noises = sorted(df['уровень_шума'].unique())

    for typ in types:
        print(f"Строю тепловую карту для {typ}...")

        # Фильтруем данные по типу звена
        df_typ = df[df['тип_звена'] == typ]

        # Создаём матрицы для 1σ, 2σ, 3σ
        matrix_1sigma = np.zeros((len(noises), len(Ts)))
        matrix_2sigma = np.zeros((len(noises), len(Ts)))
        matrix_3sigma = np.zeros((len(noises), len(Ts)))

        # Заполняем матрицы
        for i, noise in enumerate(noises):
            for j, T in enumerate(Ts):
                row = df_typ[(df_typ['уровень_шума'] == noise) & (df_typ['параметр'] == T)]
                if not row.empty:
                    matrix_1sigma[i][j] = row['ср_1σ'].values[0]
                    matrix_2sigma[i][j] = row['ср_2σ'].values[0]
                    matrix_3sigma[i][j] = row['ср_3σ'].values[0]

        # Подписи к осям
        x_labels = [f"{T}" for T in Ts]
        y_labels = [f"{noise}%" for noise in noises]

        # Тепловая карта: 1σ
        plt.figure(figsize=(10, 6))
        sns.heatmap(matrix_1sigma, annot=True, fmt=".1f", cmap="YlGnBu",
                    xticklabels=x_labels, yticklabels=y_labels)
        plt.title(f"Процент точек внутри 1σ ({typ})", fontsize=14)
        plt.xlabel("Параметр T")
        plt.ylabel("Уровень шума (%)")
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, f"{typ}_1sigma_avg.png"))
        plt.close()

        # Тепловая карта: 2σ
        plt.figure(figsize=(10, 6))
        sns.heatmap(matrix_2sigma, annot=True, fmt=".1f", cmap="YlGnBu",
                    xticklabels=x_labels, yticklabels=y_labels)
        plt.title(f"Процент точек внутри 2σ ({typ})", fontsize=14)
        plt.xlabel("Параметр T")
        plt.ylabel("Уровень шума (%)")
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, f"{typ}_2sigma_avg.png"))
        plt.close()

        # Тепловая карта: 3σ
        plt.figure(figsize=(10, 6))
        sns.heatmap(matrix_3sigma, annot=True, fmt=".1f", cmap="YlGnBu",
                    xticklabels=x_labels, yticklabels=y_labels)
        plt.title(f"Процент точек внутри 3σ ({typ})", fontsize=14)
        plt.xlabel("Параметр T")
        plt.ylabel("Уровень шума (%)")
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, f"{typ}_3sigma_avg.png"))
        plt.close()

    print(f"✅ Тепловые карты успешно сохранены в {save_dir}/")