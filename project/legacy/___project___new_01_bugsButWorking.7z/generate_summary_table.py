import pandas as pd
import os

def generate_summary_table(results, filename="results/summary_table.csv"):
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    
    summary = []

    for result in results:
        summary.append({
            'тип_звена': result['system_name'],
            'параметр': result['T'],
            'уровень_шума': result['noise_level'],
            '1σ': result['avg_1sigma'],
            '2σ': result['avg_2sigma'],
            '3σ': result['avg_3sigma']
        })

    df = pd.DataFrame(summary)
    df.to_csv(filename, index=False, encoding="utf-8-sig")
    print(f"Сводная таблица обновлена: {filename}")