import numpy as np
import pandas as pd
import os

def simulate_system(num_simulations=100, num_points=500, noise_level=0.1, tau=1):
    t = np.linspace(0, 10, num_points)
    step_input = np.ones_like(t)

    all_data = []

    for sim in range(num_simulations):
        output = np.zeros_like(step_input)
        dt = t[1] - t[0]
        y_prev = 0

        for i in range(len(t)):
            dy = (step_input[i] - y_prev) * dt / tau
            y_prev += dy
            output[i] = y_prev

        noise = np.random.normal(0, noise_level * np.std(output), size=output.shape)
        noisy_output = output + noise
        all_data.append(noisy_output.tolist())

    return all_data


def save_to_file(data, filename):
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    print(f"Saved {len(data)} simulations to {filename}")