from simulation import simulate_system, save_to_file
from build_corridors import build_corridors
from validate_in_corridors import validate
from cross_validate import cross_validate
import os

noise_levels_list = [0.1, 0.2, 0.3, 0.4, 0.5]
results_summary = []

for noise_level in noise_levels_list:
    print(f"\n{'='*60}\nRunning experiment with noise level = {int(noise_level * 100)}%\n{'='*60}")

    base_dir = f"results/noise_{int(noise_level * 100)}"
    data_dir = os.path.join(base_dir, "data")
    corridor_dir = os.path.join(base_dir, "corridors")
    validation_dir = os.path.join(base_dir, "validation")
    cross_validation_dir = os.path.join(base_dir, "cross_validation")

    os.makedirs(data_dir, exist_ok=True)
    os.makedirs(corridor_dir, exist_ok=True)
    os.makedirs(validation_dir, exist_ok=True)
    os.makedirs(cross_validation_dir, exist_ok=True)

    # Шаг 1: Моделируем первое звено (τ=1)
    simulations_tau1 = simulate_system(
        num_simulations=100, num_points=500, noise_level=noise_level, tau=1
    )
    save_to_file(simulations_tau1, os.path.join(data_dir, "system1.csv"))

    training_data = simulations_tau1[:50]
    corridor_data = build_corridors(training_data, save_path=corridor_dir)

    # Шаг 2: Проверяем оставшиеся 50 из первого звена
    validation_data = simulations_tau1[50:]
    val_stats = validate(validation_data, corridor_data, save_path=validation_dir)

    # Шаг 3: Моделируем второе звено (τ=2)
    simulations_tau2 = simulate_system(
        num_simulations=100, num_points=500, noise_level=noise_level, tau=2
    )
    save_to_file(simulations_tau2, os.path.join(data_dir, "system2.csv"))

    cross_stats = cross_validate(simulations_tau2, corridor_data, save_path=cross_validation_dir)

    # Сохранение статистики
    results_summary.append({
        'noise_level': noise_level,
        'avg_1sigma': val_stats['avg_1sigma'],
        'avg_2sigma': val_stats['avg_2sigma'],
        'avg_3sigma': val_stats['avg_3sigma'],
        'cross_avg_outside': cross_stats['avg_percent_outside']
    })

# Запись сводного отчёта
summary_path = os.path.join("results", "summary_report.txt")
with open(summary_path, "w", encoding="utf-8") as f:
    f.write("=== SUMMARY REPORT ===\n\n")
    for res in results_summary:
        nl = int(res['noise_level'] * 100)
        f.write(f"Noise Level: {nl}%\n")
        f.write(f"  Avg % in 1σ: {res['avg_1sigma']:.2f}%\n")
        f.write(f"  Avg % in 2σ: {res['avg_2sigma']:.2f}%\n")
        f.write(f"  Avg % in 3σ: {res['avg_3sigma']:.2f}%\n")
        f.write(f"  Cross-check: Avg % outside 3σ: {res['cross_avg_outside']:.2f}%\n")
        f.write("\n")

print("\nSummary report written to results/summary_report.txt")
print("All experiments completed.")