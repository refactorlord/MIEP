import numpy as np
import matplotlib.pyplot as plt
import os

def validate(data, corridor_data, save_path="results/validation"):
    os.makedirs(save_path, exist_ok=True)

    time_points = corridor_data['time']
    mean_values = corridor_data['mean']
    std_values = corridor_data['std']

    one_sigma_upper = mean_values + std_values
    one_sigma_lower = mean_values - std_values
    two_sigma_upper = mean_values + 2 * std_values
    two_sigma_lower = mean_values - 2 * std_values
    three_sigma_upper = mean_values + 3 * std_values
    three_sigma_lower = mean_values - 3 * std_values

    percent_in_1sigma_all = []
    percent_in_2sigma_all = []
    percent_in_3sigma_all = []

    for idx, series in enumerate(data):
        series = np.array(series)
        length = min(len(series), len(mean_values))

        in_1sigma = ((series >= one_sigma_lower[:length]) & (series <= one_sigma_upper[:length])).sum()
        in_2sigma = ((series >= two_sigma_lower[:length]) & (series <= two_sigma_upper[:length])).sum()
        in_3sigma = ((series >= three_sigma_lower[:length]) & (series <= three_sigma_upper[:length])).sum()

        percent_in_1sigma = in_1sigma / length * 100
        percent_in_2sigma = in_2sigma / length * 100
        percent_in_3sigma = in_3sigma / length * 100

        percent_in_1sigma_all.append(percent_in_1sigma)
        percent_in_2sigma_all.append(percent_in_2sigma)
        percent_in_3sigma_all.append(percent_in_3sigma)

        # Рисуем график
        plt.figure(figsize=(10, 6))
        plt.plot(time_points[:length], series, label='Signal')
        plt.plot(time_points[:length], mean_values[:length], '--', color='red', label='Mean')
        plt.fill_between(time_points[:length], one_sigma_lower[:length], one_sigma_upper[:length],
                         color='green', alpha=0.2, label='1σ')
        plt.fill_between(time_points[:length], two_sigma_lower[:length], two_sigma_upper[:length],
                         color='orange', alpha=0.2, label='2σ')
        plt.fill_between(time_points[:length], three_sigma_lower[:length], three_sigma_upper[:length],
                         color='yellow', alpha=0.2, label='3σ')

        plt.text(0.5, 0.95,
                 f"In 1σ: {percent_in_1sigma:.1f}%\n"
                 f"In 2σ: {percent_in_2sigma:.1f}%\n"
                 f"In 3σ: {percent_in_3sigma:.1f}%",
                 transform=plt.gca().transAxes, ha='center', va='top', fontsize=10)

        plt.title(f"Validation Simulation {idx+1}")
        plt.xlabel("Time (s)")
        plt.ylabel("Response")
        plt.legend()
        plt.grid(True)
        plt.savefig(os.path.join(save_path, f"validation_{idx+1}.png"))
        plt.close()

    avg_1sigma = np.mean(percent_in_1sigma_all)
    avg_2sigma = np.mean(percent_in_2sigma_all)
    avg_3sigma = np.mean(percent_in_3sigma_all)

    with open(os.path.join(save_path, "validation_results.txt"), "w", encoding="utf-8") as f:
        f.write("Validation Results\n")
        f.write(f"Average % of points in 1σ corridor: {avg_1sigma:.2f}%\n")
        f.write(f"Average % of points in 2σ corridor: {avg_2sigma:.2f}%\n")
        f.write(f"Average % of points in 3σ corridor: {avg_3sigma:.2f}%\n")

    print("Validation completed and saved.")
    return {
        'avg_1sigma': avg_1sigma,
        'avg_2sigma': avg_2sigma,
        'avg_3sigma': avg_3sigma
    }