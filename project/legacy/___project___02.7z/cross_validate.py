import numpy as np
import matplotlib.pyplot as plt
import os

def cross_validate(data, corridor_data, save_path="results/cross_validation"):
    os.makedirs(save_path, exist_ok=True)

    mean_values = corridor_data['mean']
    std_values = corridor_data['std']
    three_sigma_upper = mean_values + 3 * std_values
    three_sigma_lower = mean_values - 3 * std_values

    percent_outside_all = []
    time_points = corridor_data['time']

    for idx, series in enumerate(data):
        if idx >= 5:  # строим только первые 5 графиков
            break

        series = np.array(series)
        length = min(len(series), len(mean_values))
        outside = ((series < three_sigma_lower[:length]) | (series > three_sigma_upper[:length])).sum()
        percent_outside = outside / length * 100
        percent_outside_all.append(percent_outside)

        # Рисуем график
        plt.figure(figsize=(10, 6))
        plt.plot(time_points[:length], series, label='Signal')
        plt.plot(time_points[:length], mean_values[:length], '--', color='red', label='Mean from Base System')
        plt.fill_between(time_points[:length], three_sigma_lower[:length], three_sigma_upper[:length],
                         color='yellow', alpha=0.2, label='3σ Corridor')
        plt.text(0.5, 0.95,
                 f"{percent_outside:.1f}% points outside 3σ corridor",
                 transform=plt.gca().transAxes, ha='center', va='top', fontsize=10)
        plt.title(f"Cross Validation Simulation {idx+1}")
        plt.xlabel("Time (s)")
        plt.ylabel("Response")
        plt.legend()
        plt.grid(True)
        plt.savefig(os.path.join(save_path, f"cross_validation_{idx+1}.png"))
        plt.close()

    avg_percent_outside = np.mean(percent_outside_all)
    with open(os.path.join(save_path, "cross_validation_results.txt"), "w", encoding="utf-8") as f:
        f.write("Cross Validation Results\n")
        f.write(f"Average % of points outside 3σ: {avg_percent_outside:.2f}%\n")

    return {'avg_percent_outside': avg_percent_outside}