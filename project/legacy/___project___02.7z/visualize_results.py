import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

def generate_summary_table(results_data, filename="results/analysis_summary.csv"):
    df = pd.DataFrame(results_data)
    df.to_csv(filename, index=False)
    print(f"Summary table saved to {filename}")


def plot_distinguishability_matrix(matrix, labels, filename="results/distinguishability_matrix.png"):
    plt.figure(figsize=(8, 6))
    sns.heatmap(matrix, annot=True, fmt=".2f", xticklabels=labels, yticklabels=labels, cmap="YlGnBu")
    plt.title("Distinguishability Matrix (Avg % Outside 3σ)")
    plt.xlabel("Tested System Type")
    plt.ylabel("Base System Type")
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()
    print(f"Distinguishability matrix saved to {filename}")