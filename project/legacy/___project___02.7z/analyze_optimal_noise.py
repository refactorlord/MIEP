import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d

def collect_noise_results():
    noise_levels = []
    outside_percent = []

    # Сканируем основные папки экспериментов
    for folder in sorted(os.listdir("results")):
        if folder.startswith(("aperiodic", "oscillatory", "integrating", "inertial2")):
            parts = folder.split("_")
            if len(parts) >= 2 and parts[1].startswith("noise"):
                noise_level = int(parts[-1])

                # Путь к папке cross_validation
                cross_val_dir = os.path.join("results", folder, "cross_validation")

                if not os.path.exists(cross_val_dir):
                    continue

                # Теперь проходим по всем подпапкам внутри cross_validation
                for subfolder in os.listdir(cross_val_dir):
                    result_file = os.path.join(cross_val_dir, subfolder, "cross_validation_results.txt")
                    if os.path.exists(result_file):
                        with open(result_file, "r", encoding="utf-8") as f:
                            for line in f:
                                if "Average % of points outside 3σ" in line:
                                    percent = float(line.split(":")[1].strip().replace("%", ""))
                                    noise_levels.append(noise_level)
                                    outside_percent.append(percent)
                                    break

    # Убираем дубликаты, усредняем значения
    unique_levels = sorted(set(noise_levels))
    averaged_percent = []
    for level in unique_levels:
        matching = [outside_percent[i] for i, nl in enumerate(noise_levels) if nl == level]
        avg = sum(matching) / len(matching)
        averaged_percent.append(avg)

    return unique_levels, averaged_percent


def find_optimal_noise_level():
    noise_levels, outside_percent = collect_noise_results()

    if not noise_levels:
        print("No data found for analysis.")
        return

    # Сортируем данные
    combined = sorted(zip(noise_levels, outside_percent))
    noise_levels, outside_percent = zip(*combined)

    # Интерполяция
    x_fine = np.linspace(min(noise_levels), max(noise_levels), 100)
    try:
        f = interp1d(noise_levels, outside_percent, kind='quadratic', fill_value='extrapolate')
        y_fine = f(x_fine)
    except Exception as e:
        print(f"Interpolation error: {e}")
        return

    # Производная для поиска "колена"
    dy = np.gradient(y_fine, x_fine)
    min_idx = np.argmin(dy)
    optimal_noise = x_fine[min_idx]

    # График
    plt.figure(figsize=(10, 6))
    plt.scatter(noise_levels, outside_percent, color='blue', label='Original Data')
    plt.plot(x_fine, y_fine, 'r-', label='Interpolated Curve')
    plt.axvline(optimal_noise, color='green', linestyle='--',
                label=f'Optimal Noise Level: {optimal_noise:.2f}%')
    plt.xlabel('Noise Level (%)')
    plt.ylabel('Avg % Outside 3σ')
    plt.title('Finding Optimal Noise Level')
    plt.legend()
    plt.grid(True)
    plt.savefig("results/optimal_noise_analysis.png")
    plt.close()

    print(f"\n✅ Optimal noise level: {optimal_noise:.2f}%")
    return optimal_noise