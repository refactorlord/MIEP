from simulation import simulate_system, save_to_file
from build_corridors import build_corridors
from validate_in_corridors import validate
from cross_validate import cross_validate
from visualize_results import generate_summary_table, plot_distinguishability_matrix
import numpy as np
import os

# Список базовых звеньев
BASE_SYSTEMS = [
    {
        'type': 'aperiodic',
        'norm_params': {'T': 1},
        'patho_params': {'T': 2}
    },
    {
        'type': 'oscillatory',
        'norm_params': {'T': 1, 'xi': 0.5},
        'patho_params': {'T': 1.5, 'xi': 0.3}
    },
    {
        'type': 'integrating',
        'norm_params': {},
        'patho_params': {}
    },
    {
        'type': 'inertial2',
        'norm_params': {'T1': 1, 'T2': 1},
        'patho_params': {'T1': 1.5, 'T2': 2}
    }
]

# Список тестовых звеньев с близкими параметрами
TEST_SYSTEMS = [
    {
        'type': 'aperiodic',
        'params': {'T': T}
    } for T in [1.1, 1.2, 1.3, 1.4, 1.5]
]

NOISE_LEVELS = [0, 5, 10, 15, 20]  # Уменьшили шаг до 5% для точности

TYPES = ['T=1'] + [f'T={T}' for T in [1.1, 1.2, 1.3, 1.4, 1.5]]

# Для хранения результатов кросс-валидации
all_results = []

for noise_level in NOISE_LEVELS:
    print(f"\n{'='*60}\nProcessing noise level: {noise_level}%\n{'='*60}")

    base_dir = f"results/noise_{noise_level}"
    data_dir = os.path.join(base_dir, "data")
    corridor_dir = os.path.join(base_dir, "corridors")
    validation_dir = os.path.join(base_dir, "validation")
    cross_validation_dir = os.path.join(base_dir, "cross_validation")

    os.makedirs(data_dir, exist_ok=True)
    os.makedirs(corridor_dir, exist_ok=True)
    os.makedirs(validation_dir, exist_ok=True)
    os.makedirs(cross_validation_dir, exist_ok=True)

    # Массив для хранения результатов кросс-валидации
    distinguishability_data = np.zeros((len(TYPES), len(TYPES)))

    # Перебираем базовые звенья
    for base_idx, base_system in enumerate(BASE_SYSTEMS):
        base_type = base_system['type']
        base_norm_params = base_system['norm_params']

        # Шаг 1: Обучение на базовом звене
        simulations_norm = simulate_system(
            num_simulations=100, num_points=500,
            noise_level=noise_level / 100,
            system_type=base_type,
            params=base_norm_params
        )
        save_to_file(simulations_norm, os.path.join(data_dir, f"{base_type}_system_norm.csv"))

        training_data = simulations_norm[:50]
        corridor_data = build_corridors(training_data, save_path=corridor_dir)

        # Шаг 2: Валидация
        validation_data = simulations_norm[50:]
        validate(validation_data, corridor_data, save_path=validation_dir)

        # Шаг 3: Кросс-валидация с тестовыми звеньями
        for test_idx, test_system in enumerate(TEST_SYSTEMS):
            test_type = test_system['type']
            test_params = test_system['params']
            cross_dir = os.path.join(cross_validation_dir, f"T=1_T={test_params['T']}")
            os.makedirs(cross_dir, exist_ok=True)

            simulations_other = simulate_system(
                num_simulations=100, num_points=500,
                noise_level=noise_level / 100,
                system_type=test_type,
                params=test_params
            )
            save_to_file(simulations_other, os.path.join(data_dir, f"T={test_params['T']}_system_test.csv"))
            result = cross_validate(simulations_other, corridor_data, save_path=cross_dir)

            # Сохраняем средний процент выхода за 3σ
            distinguishability_data[base_idx][test_idx + 1] = result['avg_percent_outside']  # Базовое vs Тестовое
            distinguishability_data[test_idx + 1][base_idx] = result['avg_percent_outside']  # Тестовое vs Базовое

    # Сохраняем матрицу отличимости для текущего уровня шума
    matrix_filename = os.path.join(base_dir, "distinguishability_matrix.png")
    plot_distinguishability_matrix(distinguishability_data, TYPES, filename=matrix_filename)

    # Добавляем результаты в общую таблицу
    for i, base_type in enumerate(TYPES):
        for j, test_type in enumerate(TYPES):
            all_results.append({
                'base_system': base_type,
                'test_system': test_type,
                'noise_level': noise_level,
                'avg_outside_3sigma': distinguishability_data[i][j]
            })

# Сохраняем сводную таблицу
generate_summary_table(all_results, filename="results/analysis_summary.csv")