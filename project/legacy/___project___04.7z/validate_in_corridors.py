import numpy as np
import os

def validate(data, corridor_data, save_path="results/validation"):
    os.makedirs(save_path, exist_ok=True)

    mean_values = corridor_data['mean']
    std_values = corridor_data['std']

    one_sigma_upper = mean_values + std_values
    one_sigma_lower = mean_values - std_values
    two_sigma_upper = mean_values + 2 * std_values
    two_sigma_lower = mean_values - 2 * std_values
    three_sigma_upper = mean_values + 3 * std_values
    three_sigma_lower = mean_values - 3 * std_values

    percent_1sigma_all = []
    percent_2sigma_all = []
    percent_3sigma_all = []

    for series in data:
        series = np.array(series)
        length = min(len(series), len(mean_values))

        in_1sigma = ((series >= one_sigma_lower[:length]) & (series <= one_sigma_upper[:length])).sum() / length * 100
        in_2sigma = ((series >= two_sigma_lower[:length]) & (series <= two_sigma_upper[:length])).sum() / length * 100
        in_3sigma = ((series >= three_sigma_lower[:length]) & (series <= three_sigma_upper[:length])).sum() / length * 100

        percent_1sigma_all.append(in_1sigma)
        percent_2sigma_all.append(in_2sigma)
        percent_3sigma_all.append(in_3sigma)

    avg_1sigma = np.mean(percent_1sigma_all)
    avg_2sigma = np.mean(percent_2sigma_all)
    avg_3sigma = np.mean(percent_3sigma_all)

    with open(os.path.join(save_path, "validation_results.txt"), "w", encoding="utf-8") as f:
        f.write("Результаты валидации\n")
        f.write(f"Средний % точек в 1σ коридоре: {avg_1sigma:.2f}%\n")
        f.write(f"Средний % точек в 2σ коридоре: {avg_2sigma:.2f}%\n")
        f.write(f"Средний % точек в 3σ коридоре: {avg_3sigma:.2f}%\n")

    return {
        'avg_1sigma': avg_1sigma,
        'avg_2sigma': avg_2sigma,
        'avg_3sigma': avg_3sigma
    }