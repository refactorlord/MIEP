from simulation import simulate_system, save_to_file
from build_corridors import build_corridors
from validate_in_corridors import validate
from cross_validate import cross_validate
from visualize_results import generate_summary_table, plot_distinguishability_matrix
import numpy as np
import os

# Запрос у пользователя
print("Введите параметры моделирования:")
base_T = float(input("Базовое значение T (напр. 1): "))
start_T = float(input("Начальное значение тестовых T (напр. 1.1): "))
end_T = float(input("Конечное значение тестовых T (напр. 1.5): "))
step_T = float(input("Шаг изменения T (напр. 0.1): "))

print("\nВведите уровни шума (в процентах):")
noise_start = int(input("Начальный уровень шума: "))
noise_end = int(input("Конечный уровень шума: "))
noise_step = int(input("Шаг уровня шума: "))

NOISE_LEVELS = list(range(noise_start, noise_end + 1, noise_step))
T_VALUES = np.arange(start_T, end_T + step_T / 10, step_T).round(2).tolist()

SYSTEM_PAIRS = [
    {
        'type': 'aperiodic',
        'name': 'Апериодическое',
        'norm_params': {'T': base_T},
        'test_params_list': [{'T': t} for t in T_VALUES]
    },
    {
        'type': 'oscillatory',
        'name': 'Колебательное',
        'norm_params': {'T': base_T, 'xi': 0.5},
        'test_params_list': [{'T': t, 'xi': 0.5} for t in T_VALUES]
    },
    {
        'type': 'integrating',
        'name': 'Интегрирующее',
        'norm_params': {'k': 1},
        'test_params_list': [{'k': round(k, 2)} for k in np.arange(start_T, end_T + step_T, step_T).tolist()]
    },
    {
        'type': 'inertial2',
        'name': 'Инерционное II',
        'norm_params': {'T1': base_T, 'T2': base_T},
        'test_params_list': [{'T1': t, 'T2': base_T} for t in T_VALUES]
    }
]

TYPES = [s['type'] for s in SYSTEM_PAIRS]
LABELS = ['База'] + [f"T={t}" for t in T_VALUES]

all_results = []

for noise_level in NOISE_LEVELS:
    print(f"\n{'=' * 60}\nОбработка уровня шума: {noise_level}%\n{'=' * 60}")
    
    base_dir = f"results/noise_{noise_level}"
    data_dir = os.path.join(base_dir, "data")
    corridor_dir = os.path.join(base_dir, "corridors")
    validation_dir = os.path.join(base_dir, "validation")
    cross_validation_dir = os.path.join(base_dir, "cross_validation")

    os.makedirs(data_dir, exist_ok=True)

    distinguishability_data = []
    percent_1sigma = []
    percent_2sigma = []
    percent_3sigma = []

    for system_info in SYSTEM_PAIRS:
        system_type = system_info['type']
        system_name = system_info['name']
        base_params = system_info['norm_params']
        test_params_list = system_info['test_params_list']

        print(f"\nТип звена: {system_name}")

        # Обучение на базовом звене
        simulations_norm = simulate_system(
            num_simulations=100,
            num_points=500,
            noise_level=noise_level / 100,
            system_type=system_type,
            params=base_params
        )
        save_to_file(simulations_norm, os.path.join(data_dir, f"{system_type}_base.csv"))

        training_data = simulations_norm[:50]
        corridor_data = build_corridors(training_data, save_path=os.path.join(corridor_dir, system_type))

        # Кросс-валидация
        current_results = []
        percent_1 = []
        percent_2 = []
        percent_3 = []

        for test_idx, test_params in enumerate(test_params_list):
            test_value = test_params.get('T', test_params.get('k', test_params.get('T1')))
            test_label = f"{system_name}, T={test_value}"

            simulations_other = simulate_system(
                num_simulations=100,
                num_points=500,
                noise_level=noise_level / 100,
                system_type=system_type,
                params=test_params
            )

            result = cross_validate(simulations_other, corridor_data, save_path=cross_validation_dir)
            percent_1.append(result['avg_1sigma'])
            percent_2.append(result['avg_2sigma'])
            percent_3.append(result['avg_3sigma'])

            print(f"  → Тестирование с {system_name}, T={test_value}:")
            print(f"     └─ В 1σ: {result['avg_1sigma']:.2f}% | "
                  f"В 2σ: {result['avg_2sigma']:.2f}% | "
                  f"В 3σ: {result['avg_3sigma']:.2f}%")

            current_results.append({
                'тип_звена': system_name,
                'параметр': test_value,
                'уровень_шума': noise_level,
                '1σ': result['avg_1sigma'],
                '2σ': result['avg_2sigma'],
                '3σ': result['avg_3sigma']
            })

        all_results.extend(current_results)
        distinguishability_data.append(percent_3)
        percent_1sigma.append(np.mean(percent_1))
        percent_2sigma.append(np.mean(percent_2))
        percent_3sigma.append(np.mean(percent_3))

    # Сохраняем тепловые карты
    matrix_filename = os.path.join(base_dir, "distinguishability_matrix.png")
    plot_distinguishability_matrix(
        np.array(distinguishability_data),
        x_labels=[f"T={t}" for t in T_VALUES],
        y_labels=[s['name'] for s in SYSTEM_PAIRS],
        filename=matrix_filename,
        title=f"Матрица отличимости (выход за 3σ) при уровне шума {noise_level}%"
    )

generate_summary_table(all_results, filename="results/analysis_summary.csv")