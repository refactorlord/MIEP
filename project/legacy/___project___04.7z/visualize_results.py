import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os

def generate_summary_table(results_data, filename="results/summary.csv"):
    df = pd.DataFrame(results_data)
    df.to_csv(filename, index=False, encoding='utf-8-sig')
    print(f"Сводная таблица сохранена в {filename}")
    return df


def plot_distinguishability_matrix(matrix, x_labels, y_labels, filename="results/matrix.png", title="Матрица отличимости"):
    plt.figure(figsize=(10, 6))
    sns.heatmap(matrix, annot=True, fmt=".2f", xticklabels=x_labels, yticklabels=y_labels, cmap="YlGnBu", linewidths=.5)
    plt.title(title)
    plt.xlabel("Тестовые значения T")
    plt.ylabel("Тип звена")
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()
    print(f"Матрица сохранена: {filename}")