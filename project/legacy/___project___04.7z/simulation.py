import numpy as np
import pandas as pd
import os

import numpy as np
import pandas as pd
import os

def simulate_system(num_simulations=100, num_points=500, noise_level=0.1, system_type="aperiodic", params=None):
    """
    Симулирует поведение системы заданного типа с добавлением НБШ
    :param num_simulations: число симуляций
    :param num_points: количество точек на одну симуляцию
    :param noise_level: уровень шума (доля от сигнала)
    :param system_type: тип звена ('aperiodic', 'oscillatory', 'integrating', 'inertial2')
    :param params: параметры звена (например, {'T': 1} или {'T1': 1, 'T2': 1})
    :return: list[list[float]] — список симуляций
    """
    t = np.linspace(0, 10, num_points)
    step_input = np.ones_like(t)

    all_data = []

    for sim in range(num_simulations):
        if system_type == "aperiodic":
            T = params.get("T", 1)
            y_prev = 0
            dt = t[1] - t[0]
            output = []
            for i in range(len(t)):
                dy = (step_input[i] - y_prev) * dt / T
                y_prev += dy
                output.append(y_prev)

        elif system_type == "oscillatory":
            T = params.get("T", 1)
            xi = params.get("xi", 0.5)
            y_prev = 0
            v_prev = 0
            dt = t[1] - t[0]
            output = []
            for i in range(len(t)):
                a = (step_input[i] - 2 * xi * T * v_prev - y_prev) / (T**2)
                v = v_prev + a * dt
                y = y_prev + v * dt
                y_prev, v_prev = y, v
                output.append(y)

        elif system_type == "integrating":
            k = params.get("k", 1)
            y_prev = 0
            dt = t[1] - t[0]
            output = []
            for i in range(len(t)):
                y_prev += step_input[i] * dt * k
                output.append(y_prev)

        elif system_type == "inertial2":
            T1 = params.get("T1", 1)
            T2 = params.get("T2", 1)
            y1_prev = 0
            y2_prev = 0
            dt = t[1] - t[0]
            output = []
            for i in range(len(t)):
                dy1 = (step_input[i] - y1_prev) * dt / T1
                y1_prev += dy1
                dy2 = (y1_prev - y2_prev) * dt / T2
                y2_prev += dy2
                output.append(y2_prev)

        else:
            raise ValueError(f"Неизвестный тип звена: {system_type}")

        # Добавляем нормальный белый шум
        signal_std = np.std(output)
        noise = np.random.normal(0, noise_level * signal_std, size=len(output))
        noisy_output = np.array(output) + noise

        all_data.append(noisy_output.tolist())

    return all_data


def save_to_file(data, filename):
    """
    Сохраняет данные в CSV-файл, создаёт путь при необходимости
    :param data: list[list[float]]
    :param filename: str — путь к файлу
    """
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)