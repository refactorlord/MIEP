import os
import pandas as pd
import numpy as np

def analyze_noise_and_make_conclusion():
    all_data = []

    for folder in os.listdir("results"):
        if folder.startswith("noise_"):
            noise_level = int(folder.split("_")[1])
            for file in os.listdir(os.path.join("results", folder)):
                if file.endswith("analysis_summary.csv"):
                    df = pd.read_csv(os.path.join("results", folder, file))
                    df['уровень_шума'] = noise_level
                    all_data.append(df)

    if not all_data:
        print("Нет данных для анализа")
        return

    full_df = pd.concat(all_data, ignore_index=True)
    full_df.to_csv("results/full_analysis.csv", index=False, encoding='utf-8-sig')

    print("\n\n📊 Автоматический анализ:")
    for _, row in full_df.iterrows():
        perc = row["процент_выхода"]
        if perc > 70:
            print(f"[Шум {row['уровень_шума']}%, {row['тип_звена']}, T={row['параметр_T']}: ✅ Чётко различается ({perc:.1f}%)")
        elif perc > 50:
            print(f"[Шум {row['уровень_шума']}%, {row['тип_звена']}, T={row['параметр_T']}: 🔶 Отличается средне ({perc:.1f}%)")
        else:
            print(f"[Шум {row['уровень_шума']}%, {row['тип_звена']}, T={row['параметр_T']}: ❌ Не отличается ({perc:.1f}%)")